# scrap/__init__.py

"""Pacote de scraping e validações da API Tech Challenge."""
