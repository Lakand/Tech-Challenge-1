# app/__init__.py

"""Pacote principal da aplicação FastAPI com estrutura modular."""
