# auth/__init__.py

"""Pacote de autenticação: rotas e utilitários para login e criação de usuários"""
